package com.emuhub.android.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri

data class EmulatorProfile(
    val id: String,
    val name: String,
    val systems: Set<String>,
    val packageName: String,
    val acceptsGameUri: Boolean = true
)

interface EmulatorAdapter {
    val profile: EmulatorProfile
    fun buildLaunchIntent(context: Context, gameUri: Uri?): Intent? {
        val launch = context.packageManager.getLaunchIntentForPackage(profile.packageName) ?: return null
        if (gameUri != null && profile.acceptsGameUri) launch.data = gameUri
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch
    }
}
