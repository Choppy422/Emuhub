package com.emuhub.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent
import android.view.InputDevice
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("emuhub", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val games = mutableListOf<Game>()
    private var selected: Game? = null

    data class Game(val title: String, val system: String, val path: String = "", var favorite: Boolean = false, var launches: Int = 0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load(); buildUi(); showHome()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { focusedView?.performClick(); return true }
                KeyEvent.KEYCODE_BUTTON_START -> { showLibrary(); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { focusSearch(View.FOCUS_UP); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { focusSearch(View.FOCUS_DOWN); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { focusSearch(View.FOCUS_LEFT); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { focusSearch(View.FOCUS_RIGHT); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private val focusedView: View? get() = currentFocus
    private fun focusSearch(direction: Int) { currentFocus?.focusSearch(direction)?.requestFocus() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float = 14f): TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(0xFFF5F7FF.toInt()); setPadding(dp(8),dp(6),dp(8),dp(6)) }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text=text; isFocusable=true; isFocusableInTouchMode=true; setOnClickListener { action() }; isAllCaps=false }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(0xFF060811.toInt()) }
        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(8)) }
        top.addView(tv("EmuHub",25f), LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(button("⚙", ::showSettings), LinearLayout.LayoutParams(dp(55),dp(52)))
        root.addView(top)
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),0,dp(16),dp(16)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(5),dp(5),dp(7)); setBackgroundColor(0xFF0D1220.toInt()) }
        listOf("⌂ Home" to ::showHome,"▦ Library" to ::showLibrary,"★ Favorites" to ::showFavorites,"◈ Systems" to ::showSystems).forEach { (t,a)-> nav.addView(button(t,a),LinearLayout.LayoutParams(0,dp(52),1f)) }
        root.addView(nav)
        setContentView(root)
    }

    private fun title(t:String, sub:String="") { content.removeAllViews(); content.addView(tv(t,28f)); if(sub.isNotEmpty()) content.addView(tv(sub,14f)) }
    private fun panel(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(14)); setBackgroundColor(0xFF0D1220.toInt()); val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(10),0,0); layoutParams=p }
    private fun card(g:Game): LinearLayout = panel().apply {
        addView(tv(g.title,19f)); addView(tv("${g.system}  •  ${if(g.path.isEmpty()) "Demo" else g.path}",12f));
        val row=LinearLayout(this@MainActivity); row.addView(button(if(g.favorite) "★" else "☆") { toggleFavorite(g) },LinearLayout.LayoutParams(dp(60),dp(50))); row.addView(button("Details") { showDetail(g) },LinearLayout.LayoutParams(0,dp(50),1f)); addView(row)
    }
    private fun showHome(){ title("Welcome back","Your games. Your systems. One hub."); val p=panel(); p.addView(tv("OFFLINE-FIRST EMULATION HUB",11f)); p.addView(tv("Your library, your systems, one place.",30f)); p.addView(tv("Android companion • API 28+ • controller friendly",14f)); p.addView(button("Add Game Folder") { chooseFolder() }); p.addView(button("Scan Library") { scanDemo() }); content.addView(p); games.take(4).forEach { content.addView(card(it)) } }
    private fun showLibrary(){ title("Game Library","Search and launch your collection."); if(games.isEmpty()){ content.addView(tv("No games indexed yet. Add a folder or import your library.",16f)); return }; games.forEach{content.addView(card(it))} }
    private fun showFavorites(){ title("Favorites","Your starred games."); games.filter{it.favorite}.ifEmpty{listOf<Game>()}.forEach{content.addView(card(it))}; if(games.none{it.favorite}) content.addView(tv("No favorites yet.",16f)) }
    private fun showSystems(){ title("Systems","Configured and supported systems."); listOf("RetroArch","PlayStation 2 • PCSX2","GameCube / Wii • Dolphin","Wii U • Cemu","PSP • PPSSPP","PlayStation 3 • RPCS3","Xbox • xemu","Xbox 360 • Xenia").forEach{p->content.addView(panel().apply{addView(tv(p,18f));addView(tv("Configure emulator path and launch profiles in Settings.",12f))})} }
    private fun showSettings(){ title("Settings","Android library and emulator configuration."); content.addView(panel().apply{addView(tv("Emulator launch",20f));addView(tv("Android does not bundle emulator engines. Configure compatible installed apps or use the Android client as the library/controller front-end.",14f));addView(button("Choose Game Folder",::chooseFolder));addView(button("Rescan",::scanDemo));addView(button("Export Library",::exportLibrary))}); content.addView(panel().apply{addView(tv("Performance",20f));addView(tv("Preset: Balanced\nResolution scaling: 100%\nFrame pacing: Auto\nThese settings are shared preferences for the Android front-end and can later map to emulator-specific profiles.",14f))}) }
    private fun showDetail(g:Game){selected=g; title(g.title,"${g.system} • ${g.launches} launches"); content.addView(card(g)); content.addView(panel().apply{addView(tv("Launch profile",20f));val exe=EditText(this@MainActivity).apply{hint="Emulator/app package or command"};val args=EditText(this@MainActivity).apply{hint="Arguments / profile notes"};addView(exe);addView(args);addView(button("Save Profile"){prefs.edit().putString("profile_${g.title}","${exe.text}|${args.text}").apply();toast("Profile saved")})});content.addView(button("Launch / Open Game") { launch(g) });content.addView(button("Save Folder") { toast("Android save-folder integration is ready for emulator-specific adapters") })}
    private fun toggleFavorite(g:Game){g.favorite=!g.favorite;save();showDetail(g)}
    private fun launch(g:Game){
        g.launches++; save()
        val profile = prefs.getString("profile_${g.title}", "") ?: ""
        val packageName = profile.substringBefore('|').trim()
        if (packageName.isNotEmpty()) {
            try {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (g.path.isNotEmpty()) launch.data = Uri.parse(g.path)
                    startActivity(launch); showDetail(g); return
                }
            } catch (_: Exception) {}
        }
        if(g.path.startsWith("content://")){
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.path))); showDetail(g); return } catch (_: Exception) {}
        }
        toast("No Android launch adapter configured for ${g.system}. Set the installed emulator package in Launch Profile.")
        showDetail(g)
    }
    private fun chooseFolder(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),1001)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==1001&&resultCode==RESULT_OK){data?.data?.let{uri->contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs.edit().putString("gameFolder",uri.toString()).apply();toast("Game folder connected");scanDemo()}}}
    private fun scanDemo(){if(games.isEmpty()){games += Game("Neon Horizon","N64");games += Game("Shadow Circuit","PlayStation 2");games += Game("Starfall 64","N64");games += Game("Blood Moon","Dreamcast");save()};showLibrary();toast("Library scan complete")}
    private fun exportLibrary(){val text=JSONArray(games.map{JSONObject().apply{put("title",it.title);put("system",it.system);put("path",it.path);put("favorite",it.favorite);put("launches",it.launches)}}).toString(2);val i=Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_TEXT,text)};startActivity(Intent.createChooser(i,"Export EmuHub library"))}
    private fun save(){val a=JSONArray();games.forEach{a.put(JSONObject().apply{put("title",it.title);put("system",it.system);put("path",it.path);put("favorite",it.favorite);put("launches",it.launches)})};prefs.edit().putString("games",a.toString()).apply()}
    private fun load(){val s=prefs.getString("games",null)?:return;try{val a=JSONArray(s);for(i in 0 until a.length()){val o=a.getJSONObject(i);games+=Game(o.optString("title"),o.optString("system"),o.optString("path"),o.optBoolean("favorite"),o.optInt("launches"))}}catch(_:Exception){}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
