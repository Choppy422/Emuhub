package com.emuhub.android.adapter

object BuiltInAdapters {
    fun profiles() = listOf(
        EmulatorProfile("retroarch", "RetroArch", setOf("NES","SNES","Genesis","N64","PS1","Dreamcast","GBA","Game Boy"), "com.retroarch"),
        EmulatorProfile("aethersx2", "AetherSX2", setOf("PlayStation 2"), "xyz.aethersx2.android"),
        EmulatorProfile("nether", "NetherSX2", setOf("PlayStation 2"), "com.github.i2aysh.nethersx2"),
        EmulatorProfile("dolphin", "Dolphin", setOf("GameCube","Wii"), "org.dolphinemu.dolphinemu"),
        EmulatorProfile("ppsspp", "PPSSPP", setOf("PSP"), "org.ppsspp.ppsspp"),
        EmulatorProfile("duckstation", "DuckStation", setOf("PlayStation"), "com.github.stenzek.duckstation"),
        EmulatorProfile("lemuroid", "Lemuroid", setOf("NES","SNES","Genesis","N64","PS1","Dreamcast","GBA","Game Boy","PSP"), "com.swordfish.lemuroid"),
        EmulatorProfile("citra", "Citra-compatible", setOf("Nintendo 3DS"), "org.citra.citra_emu")
    )
}
