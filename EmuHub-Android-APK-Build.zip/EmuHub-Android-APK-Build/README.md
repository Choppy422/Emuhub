# EmuHub Android 0.5.0 Beta 3

- Minimum Android API 28
- Native Kotlin client
- Storage Access Framework folder permissions
- Persistent offline library
- Favorites and per-game launch profiles
- Android package-based emulator launching
- Content-URI game launching where supported by the installed emulator
- D-pad / A / Start controller navigation

## Build

Requires Android Studio or a machine with Android SDK + Gradle. Open this directory as an Android project and build `app`.

The repository intentionally does not contain ROMs, BIOS/firmware, or proprietary emulator engines.

## Launch profiles

In Game Details, enter the Android package name of the emulator (for example, an installed emulator's application ID). EmuHub asks Android for that package's launch activity and attaches the selected game URI when the emulator accepts it.
