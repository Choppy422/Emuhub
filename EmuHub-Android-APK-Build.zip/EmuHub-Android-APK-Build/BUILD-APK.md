# EmuHub Android APK — one-click build

This is the Android EmuHub project (minimum Android API 28) with a GitHub Actions workflow that builds the APK automatically.

## Phone-friendly build
1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload **everything inside this folder** to the repository root.
4. Open the repository's **Actions** tab.
5. Select **Build EmuHub APK**.
6. Tap **Run workflow**.
7. When it finishes, open the run and download the **EmuHub-debug-apk** artifact.
8. Extract the artifact and install the APK on Android. You may need to allow installation from that file source.

The APK is a launcher/frontend. It does not include copyrighted ROMs, BIOS/firmware, or emulator binaries.
